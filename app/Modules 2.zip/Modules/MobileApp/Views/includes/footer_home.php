<?php
/**
 * Created by PhpStorm.
 * User: oluwamayowasteepe
 * Project: epr-event-portal
 * Date: 11/11/2025
 * Time: 21:40
 */
?>

<footer class="border-t mt-10 py-4 text-center text-xs text-white-50">
    © <?php echo date('Y'); ?> EPR Event Portal. All rights reserved.
</footer>
</body>
</html>

