<?php
/**
 * Created by PhpStorm.
 * User: Oluwamayowa Steepe
 * Project: eprglobal
 * Date: 29/08/2021
 * Time: 02:42
 */
?>

<body class="home-bg">

    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: transparent;">

        <a class="navbar-brand float-left" href="#">
            <img src="<?php echo asset_url('images/eventslogo.png');?>" width="200px" alt="emergence-logo">
        </a>

        <a class="navbar-nav flex-row ml-md-auto d-none d-md-flex">
            <!--<img src="<?php /*echo asset_url('images/innovate-logo.png');*/?>" width="200px" alt="innovate-logo">-->
        </a>
    </nav>
