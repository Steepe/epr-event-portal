<?php
/**
 * Created by PhpStorm.
 * User: oluwamayowasteepe
 * Project: epr-event-portal
 * Date: 27/10/2025
 * Time: 10:03
 */

namespace App\Modules\Api\Controllers;

use App\Controllers\BaseController;

class Events extends BaseController
{

}