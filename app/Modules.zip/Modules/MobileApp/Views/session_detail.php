<?php
/**
 * Created by PhpStorm.
 * User: oluwamayowasteepe
 * Project: epr-event-portal
 * Date: 12/11/2025
 * Time: 05:56
 */

echo module_view('MobileApp', 'includes/header');

$event           = $session ?? [];
$sessionSpeakers = $speakers ?? [];
$timezone        = $timezone ?? 'Africa/Lagos';
$plan            = (int)(session('plan') ?? 1);

// 🧩 Access control (force integer)
$accessLevel = (int)($event['access_level'] ?? 1);
$canAccess   = $plan >= $accessLevel;

$vimeo_id  = trim($event['vimeo_id'] ?? '');
$videoSrc  = '';

if (!empty($vimeo_id)) {
    if (is_numeric($vimeo_id)) {
        $videoSrc = "https://player.vimeo.com/video/" . $vimeo_id;
    } elseif (str_contains($vimeo_id, 'event')) {
        $videoSrc = "https://vimeo.com/{$vimeo_id}/embed";
    } else {
        $videoSrc = "https://vimeo.com/event/{$vimeo_id}/embed";
    }
}

// 🕓 Session Timing
$startTime = isset($event['start_time']) ? date('h:i A', strtotime($event['start_time'])) : null;
$endTime   = isset($event['end_time']) ? date('h:i A', strtotime($event['end_time'])) : null;
$eventDate = isset($event['event_date']) ? date('F j, Y', strtotime($event['event_date'])) : null;
?>

<style>
    body {
        background-image: url('<?php echo asset_url('images/mobile-brain-light.png'); ?>');
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed; /* 🔥 Keeps background fixed during scroll */
        font-family: 'Inter', 'Poppins', sans-serif;
        min-height: 100vh;
        color: #A70B91;
        overflow-x: hidden;
        overflow-y: auto; /* 🔥 Ensure only content scrolls */
    }

    .overlay-gradient {
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        z-index: -1;
    }

    .session-container {
        padding: 1.5rem;
        text-align: center;
        max-width: 600px;
        margin: 10px auto auto;
    }

    h4 {
        color: #A70B91;
        margin-bottom: 0.4rem;
        font-weight: 700;
        font-size: 1.4rem;
    }

    .session-meta {
        font-size: 0.85rem;
        color: #ddd;
        margin-bottom: 1rem;
    }

    .session-meta span {
        display: block;
        line-height: 1.4;
    }

    /* 🎥 Video Box */
    .video-wrapper {
        position: relative;
        width: 100%;
        padding-top: 56.25%;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 8px 25px rgba(0,0,0,0.4);
        margin-bottom: 1.5rem;
    }

    iframe {
        position: absolute;
        top: 0; left: 0;
        width: 100%; height: 100%;
        border: none;
        border-radius: 16px;
    }

    .locked-video {
        background: rgba(0, 0, 0, 0.5);
        border: 1px solid rgba(255,216,77,0.3);
        border-radius: 16px;
        height: 200px;
        display: flex;
        justify-content: center;
        align-items: center;
        color: #fff;
        font-size: 0.95rem;
        font-weight: 500;
        text-shadow: 0 2px 6px rgba(0,0,0,0.3);
        margin-bottom: 1.5rem;
    }

    .locked-video i {
        font-size: 1.2rem;
        margin-right: 8px;
        color: #f3bb1a;
    }

    .feedback-row {
        margin-top: 1rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 0.85rem;
    }

    .like-icon i {
        color: #f3bb1a;
        font-size: 1.2rem;
        cursor: pointer;
        transition: color 0.3s;
    }

    .like-icon i.filled {
        color: #E91E63;
    }

    .rating-stars {
        direction: rtl;
        display: flex;
        gap: 4px;
    }

    .rating-stars input { display: none; }
    .rating-stars label {
        font-size: 1.1rem;
        color: #777;
        cursor: pointer;
        transition: color 0.3s;
    }

    .rating-stars input:checked ~ label,
    .rating-stars label:hover,
    .rating-stars label:hover ~ label {
        color: #f3bb1a;
    }

    .speaker-section {
        margin-top: 1.5rem;
        text-align: left;
    }

    .speaker-card {
        display: flex;
        align-items: center;
        background: rgba(255,255,255,0.08);
        border: 1px solid rgba(255,255,255,0.2);
        border-radius: 14px;
        padding: 10px;
        margin-bottom: 0.8rem;
    }

    .speaker-card img {
        width: 70px;
        height: 70px;
        border-radius: 10px;
        object-fit: cover;
        margin-right: 10px;
    }

    .speaker-info h6 {
        font-size: 0.95rem;
        font-weight: 600;
        color: #f3bb1a;
        margin-bottom: 2px;
    }

    .speaker-info p {
        font-size: 0.8rem;
        margin: 0;
        color: #ddd;
    }

    .session-overview {
        background: rgba(255,255,255,0.08);
        border-radius: 14px;
        padding: 1rem;
        margin-top: 1.5rem;
        text-align: left;
    }

    .session-overview h6 {
        color: #A70B91;
        font-weight: 600;
        margin-bottom: 8px;
    }

    .session-overview p {
        font-size: 0.9rem;
        color: #fff;
        line-height: 1.5;
    }

    .btn-download {
        display: inline-block;
        margin-top: 1rem;
        color: #fff;
        border: none;
        border-radius: 30px;
        padding: 10px 10px;
        font-weight: 600;
        text-decoration: none;
        font-size: 0.9rem;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        transition: transform 0.2s ease;
        width: 170px;
    }

    .btn-download:hover {
        transform: scale(1.05);
    }

    @media (max-width: 480px) {
        h4 { font-size: 1.2rem; }
        .speaker-card img { width: 60px; height: 60px; }
    }

    /* ===========================================================
       BOTTOM SLIDING CHAT DRAWER
    =========================================================== */
    .chat-drawer {
        position: fixed;
        bottom: -100%;
        left: 0;
        width: 100%;
        height: 70%;
        background: rgba(255,255,255,0.15);
        backdrop-filter: blur(15px);
        border-radius: 20px 20px 0 0;
        box-shadow: 0 -4px 25px rgba(0,0,0,0.35);
        transition: bottom 0.35s ease;
        z-index: 999999;
        display: flex;
        flex-direction: column;
        padding: 0;
    }

    .chat-drawer.active {
        bottom: 0;
    }

    .chat-overlay {
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.45);
        z-index: 999998;
        display: none;
    }

    .chat-overlay.active {
        display: block;
    }

    /* ===========================================================
       CHAT HEADER
    =========================================================== */
    .chat-header {
        padding: 14px 18px;
        background: rgba(0,0,0,0.25);
        backdrop-filter: blur(8px);
        color: #fff;
        font-weight: 600;
        font-size: 1rem;
        border-radius: 20px 20px 0 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .chat-close-btn {
        background: none;
        border: none;
        font-size: 26px;
        color: #fff;
        cursor: pointer;
        margin-top: -4px;
    }

    /* ===========================================================
       OPTION A – MINIMAL GLASS CHAT UI
    =========================================================== */
    /* ===========================================================
       PREMIUM CHAT BUBBLES (Mobile Native)
    =========================================================== */

    .chat-bubble-wrapper {
        display: flex;
        align-items: flex-end;
        margin-bottom: 14px;
    }

    .chat-bubble-wrapper.me {
        justify-content: flex-end;
    }

    .chat-bubble-wrapper.them {
        justify-content: flex-start;
    }

    .chat-avatar {
        width: 34px;
        height: 34px;
        border-radius: 50%;
        object-fit: cover;
        margin-right: 8px;
        border: 2px solid rgba(255,255,255,0.4);
    }

    .chat-bubble-wrapper.me .chat-avatar {
        display: none;
    }

    .chat-bubble {
        position: relative;
        padding: 10px 14px;
        border-radius: 16px;
        max-width: 78%;
        line-height: 1.45;
    }

    .chat-bubble.me {
        background: linear-gradient(135deg, #A70B91, #d215bf);
        color: #fff;
        border-bottom-right-radius: 4px;
    }

    .chat-bubble.them {
        background: rgba(255,255,255,0.90);
        color: #222;
        border-bottom-left-radius: 4px;
    }

    /* Name above bubble */
    .chat-name {
        font-size: 0.72rem;
        font-weight: 700;
        margin-bottom: 4px;
        opacity: 0.9;
        color: #ffe7fb;
    }

    /* Incoming show name in theme color */
    .chat-bubble-wrapper.them .chat-name {
        color: #A70B91;
    }

    /* Time styling */
    .chat-time {
        font-size: 0.70rem;
        margin-top: 6px;
        opacity: 0.7;
        text-align: right;
    }

    .chat-drawer {
        position: fixed;
        bottom: -100%;
        left: 0;
        width: 100%;
        height: 72%;
        background: rgba(25, 0, 20, 0.55);
        backdrop-filter: blur(22px) saturate(180%);
        border-radius: 22px 22px 0 0;
        box-shadow: 0 -4px 28px rgba(0,0,0,0.4);
        transition: bottom 0.32s cubic-bezier(0.24,0.61,0.35,1);
        z-index: 999999;
        display: flex;
        flex-direction: column;
    }

    .chat-header {
        padding: 16px 20px;
        background: rgba(255,255,255,0.10);
        backdrop-filter: blur(10px);
        color: #fff;
        font-weight: 600;
        font-size: 1rem;
        border-radius: 22px 22px 0 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        letter-spacing: .3px;
    }

    .chat-close-btn {
        background: rgba(255,255,255,0.18);
        border: none;
        font-size: 22px;
        padding: 4px 10px;
        border-radius: 12px;
        color: #fff;
        cursor: pointer;
    }

    .chat-input-row {
        background: rgba(255,255,255,0.08);
        backdrop-filter: blur(10px);
        padding: 10px 12px;
        border-radius: 16px;
        display: flex;
        gap: 8px;
        margin-top: 12px;
        align-items: center;
    }

    .chat-input {
        flex: 1;
        border-radius: 14px;
        border: 1px solid rgba(255,255,255,0.25);
        padding: 12px;
        background: rgba(255,255,255,0.18);
        color: #fff;
        height: 48px;
        max-height: 130px;
    }

    .chat-send-btn {
        background: linear-gradient(135deg, #A70B91, #d215bf);
        border-radius: 14px;
        border: none;
        padding: 12px 16px;
        color: #fff;
        font-weight: 700;
        font-size: .9rem;
        display: flex;
        align-items: center;
    }

    /* FIX SCROLLING — FORCE CHAT AREA TO BE SCROLLABLE */
    .chat-glass {
        flex: 1;
        display: flex;
        flex-direction: column;
        overflow: hidden; /* IMPORTANT */
    }

    .chat-messages {
        flex: 1;
        overflow-y: auto !important;
        padding: 10px;
        min-height: 0; /* CRITICAL FIX */
    }

    .chat-messages::-webkit-scrollbar {
        width: 5px;
    }
    .chat-messages::-webkit-scrollbar-track {
        background: rgba(255,255,255,0.1);
    }
    .chat-messages::-webkit-scrollbar-thumb {
        background: rgba(255,255,255,0.35);
        border-radius: 20px;
    }

    .chat-bubble-wrapper.pending .chat-bubble { opacity: 0.7; filter: blur(0.1px); }
    .chat-bubble-wrapper.failed .chat-bubble { border: 1px solid rgba(255,0,0,0.2); opacity: 0.7; }

</style>

<div class="overlay-gradient"></div>

<div class="session-container">
    <!-- 🏷️ Title + Date/Time -->
    <h4><?php echo esc($event['sessions_name'] ?? 'Session'); ?></h4>

    <?php if ($eventDate || $startTime): ?>
        <div class="session-meta">
            <?php if ($eventDate): ?><span><?php echo esc($eventDate); ?></span><?php endif; ?>
            <?php if ($startTime && $endTime): ?><span><?php echo "{$startTime} - {$endTime} ({$timezone})"; ?></span><?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- 🎥 Video -->
    <?php if ($canAccess && !empty($videoSrc)): ?>
        <div class="video-wrapper">
            <iframe src="<?php echo esc($videoSrc); ?>"
                    allow="autoplay; fullscreen; picture-in-picture"
                    allowfullscreen></iframe>
        </div>
    <?php elseif (empty($videoSrc)): ?>
        <div class="locked-video">
            <i class="fa fa-info-circle"></i> This session does not have a video available yet.
        </div>
    <?php else: ?>
        <div class="locked-video">
            <i class="fa fa-lock"></i> Please upgrade your ticket to access this session.
        </div>
    <?php endif; ?>

    <!-- 💬 Feedback & Like -->
    <div class="feedback-row">
        <div class="like-icon" id="likeSession">
            <i class="fa fa-heart-o"></i> <span>Like</span>
        </div>
        <div class="rating-stars">
            <?php for ($i = 5; $i >= 1; $i--): ?>
                <input type="radio" id="star<?php echo $i; ?>" name="rating" value="<?php echo $i; ?>">
                <label for="star<?php echo $i; ?>">★</label>
            <?php endfor; ?>
        </div>
    </div>

    <!-- 👥 Speakers -->
    <?php if (!empty($sessionSpeakers)): ?>
        <div class="speaker-section">
            <h6 style="color:#f3bb1a; margin-bottom:8px;">Speakers</h6>
            <?php foreach ($sessionSpeakers as $speaker): ?>
                <div class="speaker-card">
                    <img src="<?php echo base_url('uploads/speaker_pictures/' . ($speaker['speaker_photo'] ?? '')); ?>"
                         onerror="this.src='<?php echo asset_url('images/user.png'); ?>';"
                         alt="<?php echo esc($speaker['speaker_name']); ?>">
                    <div class="speaker-info">
                        <h6><?php echo esc($speaker['speaker_name']); ?></h6>
                        <p><?php echo esc(($speaker['speaker_title'] ?? '') . ', ' . ($speaker['speaker_company'] ?? '')); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- 📝 Session Overview -->
    <div class="session-overview">
        <h6>Overview</h6>
        <p><?php echo nl2br(esc($event['description'] ?? 'No description available.')); ?></p>

        <?php if (!empty($event['workbook'])): ?>
            <a href="<?php echo base_url('uploads/workbooks/' . $event['workbook']); ?>" download class="btn-download epr-btn-four">
                Download Workbook
            </a>
        <?php endif; ?>
        <button class="btn-download epr-btn-four" onclick="openChatDrawer()">
            Live Chat
        </button>
    </div>
</div>

<!-- ===========================================================
     SLIDING CHAT DRAWER (BOTTOM SHEET)
=========================================================== -->
<div id="chatDrawer" class="chat-drawer">

    <div class="chat-header">
        <span>Live Chat</span>
        <button class="chat-close-btn" onclick="closeChatDrawer()">×</button>
    </div>

    <!-- OPTION A — Minimal Glass Chat -->
    <div id="chat-container" class="chat-glass">
        <div id="chat-messages" class="chat-messages"></div>

        <div class="chat-input-row">
            <textarea id="chatInput" class="chat-input" placeholder="Type a message..."></textarea>
            <button class="chat-send-btn" onclick="sendMessage()">Send</button>
        </div>
    </div>

</div>

<!-- Overlay -->
<div id="chatOverlay" class="chat-overlay" onclick="closeChatDrawer()"></div>

<script>
    function openChatDrawer() {
        document.getElementById("chatDrawer").classList.add("active");
        document.getElementById("chatOverlay").classList.add("active");
    }

    function closeChatDrawer() {
        document.getElementById("chatDrawer").classList.remove("active");
        document.getElementById("chatOverlay").classList.remove("active");
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>

<!-- Emoji Picker Web Component -->
<script type="module" src="https://unpkg.com/emoji-picker-element@latest/index.js"></script>

<!-- Tribute.js (Mentions) -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tributejs@5.1.3/dist/tribute.css">
<script src="https://cdn.jsdelivr.net/npm/tributejs@5.1.3/dist/tribute.min.js"></script>

<script>
    /* ======= MOBILE CHAT: Supabase realtime + Mentions + Emoji =======
       Paste this at the end of the mobile session_detail page (before footer).
       Replaces previous mobile chat script blocks.
    ================================================================== */

    (async function() {
        // --- server-provided config (PHP -> JS)
        const BASE_URL        = "<?php echo base_url(); ?>";
        const SUPABASE_URL    = "<?php echo getenv('supabase.url'); ?>";
        const SUPABASE_ANON   = "<?php echo getenv('supabase.anon_key'); ?>";
        const API_KEY         = "<?php echo env('api.securityKey'); ?>";
        const SESSION_ID      = "<?php echo $event['sessions_id']; ?>";
        const ATTENDEE_ID     = "<?php echo session('attendee_id'); ?>";
        const API_CHAT_SEND   = BASE_URL + "api/chat/send/" + SESSION_ID;
        const API_USERS_BASE  = BASE_URL + "api/users/";           // append userId
        const API_ATTENDEES   = BASE_URL + "api/attendees/all";


        // --- DOM
        const chatBox   = document.getElementById("chat-messages");
        const chatInput = document.getElementById("chatInput");
        if (!chatBox || !chatInput) {
            console.error("Chat DOM missing: #chat-messages or #chatInput not found.");
            return;
        }

        // --- state
        const profileCache = {};         // id -> profile
        const seenMessageIds = new Set(); // avoid duplicates from optimistic + realtime

        // --- utils
        function scrollChatDown() { try { chatBox.scrollTop = chatBox.scrollHeight; } catch(e){} }
        function safeHTML(s) {
            if (s == null) return "";
            return String(s)
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;")
                .replace(/\n/g, "<br>");
        }

        // sanitize but allow <a> (rest escaped). We use placeholder markers to restore mention links.
        function sanitizeAllowLinks(s) {
            if (!s) return "";
            const placeholders = [];
            s = s.replace(/\[\[MENTION:([\s\S]*?)\]\]/g, (m, inner) => {
                placeholders.push(inner);
                return `[[MENTION_PL_${placeholders.length-1}]]`;
            });
            let escaped = safeHTML(s);
            placeholders.forEach((html, i) => {
                escaped = escaped.replace(`[[MENTION_PL_${i}]]`, html);
            });
            return escaped;
        }

        // load + cache user profile (uses base_url API)
        async function getUserProfile(userId) {
            if (!userId) return { firstname: "User", lastname: userId, profile_picture: "" };
            if (profileCache[userId]) return profileCache[userId];
            try {
                const res = await fetch(API_USERS_BASE + userId, {
                    headers: { "X-API-KEY": API_KEY }
                });
                const j = await res.json();
                if (j && j.status === "success" && j.data) {
                    profileCache[userId] = j.data;
                    return j.data;
                }
            } catch (err) { console.warn("getUserProfile failed", err); }
            profileCache[userId] = { firstname: "User", lastname: userId, profile_picture: "" };
            return profileCache[userId];
        }

        // convert token @{user:ID} -> placeholder markup for safe sanitizer to restore later
        function tokensToMentionMarkup(msg) {
            return msg.replace(/@\{user:(\d+)\}/g, (m, id) => {
                const p = profileCache[id];
                const fullname = p ? `${p.firstname||""} ${p.lastname||""}`.trim() : ("User " + id);
                const profileUrl = BASE_URL + "attendees/profile/" + id;
                const html = `<a href="${profileUrl}" class="mention-link" style="color:#ff4eb8;font-weight:600;text-decoration:none">@${safeHTML(fullname)}</a>`;
                return `[[MENTION:${html}]]`;
            });
        }

        // convert raw @Full Name -> a link if matches cached profiles
        function rawNamesToLink(msg) {
            // iterate cached names and replace
            for (let id in profileCache) {
                const p = profileCache[id];
                if (!p) continue;
                const fullname = `${p.firstname||""} ${p.lastname||""}`.trim();
                if (!fullname) continue;
                // word boundary + case-insensitive
                const esc = fullname.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
                const rx = new RegExp("@" + esc, "gi");
                const profileUrl = BASE_URL + "attendees/profile/" + id;
                const link = `<a href="${profileUrl}" class="mention-link" style="color:#ff4eb8;font-weight:600;text-decoration:none">@${safeHTML(fullname)}</a>`;
                msg = msg.replace(rx, link);
            }
            return msg;
        }

        // render message bubble (message object: id, session_id, attendee_id, message, created_at, parent_id)
        async function renderMessage(msg) {
            if (!msg || !msg.id) {
                // allow optimistic temp messages with no id? we skip here to avoid confusion
            } else {
                if (seenMessageIds.has(String(msg.id))) return; // already rendered
                seenMessageIds.add(String(msg.id));
            }

            const user = await getUserProfile(msg.attendee_id);
            const fullname = `${user.firstname||""} ${user.lastname||""}`.trim();
            const avatar = user.profile_picture ? (BASE_URL + "uploads/profile_pictures/" + user.profile_picture) : "<?php echo asset_url('images/user.png'); ?>";
            const isMe = String(msg.attendee_id) === String(ATTENDEE_ID);

            // replace tokens and raw names, then sanitize (allow mention <a>)
            let body = msg.message || "";
            body = rawNamesToLink(body);
            body = tokensToMentionMarkup(body);
            body = sanitizeAllowLinks(body);

            const bubble = document.createElement("div");
            bubble.className = "chat-bubble-wrapper " + (isMe ? "me" : "them");
            bubble.innerHTML = `
      ${!isMe ? `<img src="${avatar}" class="chat-avatar" onerror="this.src='<?php echo asset_url('images/user.png'); ?>'">` : ""}
      <div class="chat-bubble ${isMe ? 'me' : 'them'}">
        <div class="chat-name">${safeHTML(fullname)}</div>
        <div class="chat-text">${body}</div>
        <div class="chat-time">${new Date(msg.created_at || Date.now()).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</div>
      </div>
    `;
            chatBox.appendChild(bubble);
            scrollChatDown();
        }

        // load initial mentions list (attendees), preload profileCache
        async function loadMentionsAndCache() {
            try {
                const res = await fetch(API_ATTENDEES, { headers: { "X-API-KEY": API_KEY } });
                const j = await res.json();
                if (!j || !Array.isArray(j.data)) {
                    console.warn("attendees/all returned unexpected", j);
                    return;
                }
                for (const a of j.data) {
                    const id = String(a.id);
                    profileCache[id] = {
                        firstname: a.firstname || "",
                        lastname: a.lastname || "",
                        profile_picture: a.profile_picture || ""
                    };
                }

                // build Tribute values (fullname)
                const tributeValues = j.data.map(a => ({ key: `${a.firstname||""} ${a.lastname||""}`.trim(), id: a.id }));
                const tribute = new Tribute({
                    trigger: "@",
                    values: tributeValues,
                    lookup: "key",
                    menuItemTemplate: item => item.string,
                    selectTemplate: item => "@" + item.original.key
                });
                tribute.attach(chatInput);
                console.log("Mentions loaded:", tributeValues.length, "users");
            } catch (err) {
                console.warn("loadMentionsAndCache failed", err);
            }
        }

        // load chat history from supabase REST
        async function loadChatHistory() {
            try {
                const url = `${SUPABASE_URL}/rest/v1/tbl_session_chats?session_id=eq.${SESSION_ID}&order=id.asc`;
                const res = await fetch(url, {
                    headers: {
                        "apikey": SUPABASE_ANON,
                        "Authorization": "Bearer " + SUPABASE_ANON
                    }
                });
                const msgs = await res.json();
                if (!Array.isArray(msgs)) return;
                for (const m of msgs) {
                    await renderMessage(m);
                }
            } catch (err) {
                console.warn("loadChatHistory failed", err);
            }
        }

        // send message to your CI4 API which writes to Supabase (expected)
        async function sendMessage() {
            try {
                let raw = chatInput.value || "";
                raw = raw.trim();
                if (!raw) return;

                // convert displayed @Full Name -> @{user:ID} using cache
                for (let id in profileCache) {
                    const p = profileCache[id];
                    const fullname = `${p.firstname||""} ${p.lastname||""}`.trim();
                    if (!fullname) continue;
                    const esc = fullname.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
                    raw = raw.replace(new RegExp("@" + esc, "gi"), `@{user:${id}}`);
                }

                const res = await fetch(API_CHAT_SEND, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-API-KEY": API_KEY
                    },
                    credentials: "include",
                    body: JSON.stringify({ attendee_id: ATTENDEE_ID, message: raw })
                });

                // inspect response
                let j = null;
                try { j = await res.json(); } catch(e){ /* may be empty */ }

                if (!res.ok) {
                    console.warn("sendMessage failed", res.status, j);
                    // show toast or console only — do not optimistic-insert if server didn't create record
                    return;
                }

                // If backend returns created row, render it now (keeps UI immediate)
                // Expect j.data or j.record — check what your endpoint returns. We'll attempt common shapes:
                if (j && j.data && Array.isArray(j.data) && j.data[0]) {
                    await renderMessage(j.data[0]);
                } else if (j && j.id) {
                    await renderMessage(j);
                } // otherwise rely on realtime event to arrive

                chatInput.value = "";

            } catch (err) {
                console.error("sendMessage exception", err);
            }
        }

        // expose globally for onclick
        window.sendMessage = sendMessage;

        // Enter to send (mobile: okay to keep)
        chatInput.addEventListener("keydown", (e) => {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        // --- Supabase realtime subscription
        try {
            const channel = supabaseClient
                .channel("session-" + SESSION_ID)
                .on("postgres_changes", {
                    event: "INSERT",
                    schema: "public",
                    table: "tbl_session_chats",
                    filter: "session_id=eq." + SESSION_ID
                }, payload => {
                    try {
                        renderMessage(payload.new);
                    } catch (err) {
                        console.warn("renderMessage failed:", err);
                    }
                })
                .subscribe();

            console.log("Supabase realtime subscribed for session", SESSION_ID, channel);
        } catch (err) {
            console.warn("Supabase init failed", err);
        }

        // Typing indicator helpers (optional): make calls but swallow 404s so no console spam
        async function notifyTypingStart() {
            try {
                await fetch(BASE_URL + "api/chat/typing/" + SESSION_ID, {
                    method: "POST",
                    headers: { "Content-Type": "application/json", "X-API-KEY": API_KEY },
                    credentials: "include",
                    body: JSON.stringify({ attendee_id: ATTENDEE_ID })
                });
            } catch(e){ /* ignore */ }
        }
        async function notifyTypingStop() {
            try {
                await fetch(BASE_URL + "api/chat/typing/" + SESSION_ID, {
                    method: "DELETE",
                    headers: { "Content-Type": "application/json", "X-API-KEY": API_KEY },
                    credentials: "include",
                    body: JSON.stringify({ attendee_id: ATTENDEE_ID })
                });
            } catch(e){ /* ignore */ }
        }
        let typingTimer = null;
        chatInput.addEventListener("input", () => {
            notifyTypingStart();
            if (typingTimer) clearTimeout(typingTimer);
            typingTimer = setTimeout(() => notifyTypingStop(), 2500);
        });

        // INIT sequence: load mentions (cache) FIRST, then history
        await loadMentionsAndCache();
        await loadChatHistory();
        scrollChatDown();

        console.log("Chat initialized (mobile). session:", SESSION_ID, "attendee:", ATTENDEE_ID);

    })();
</script>


<?php echo module_view('MobileApp', 'includes/footer'); ?>
